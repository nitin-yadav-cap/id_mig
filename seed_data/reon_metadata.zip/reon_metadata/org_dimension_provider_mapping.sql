-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: reon_metadata_2020_06_05_11_49
-- ------------------------------------------------------
-- Server version	5.7.30-0ubuntu0.18.04.1-log





--
-- Dumping data for table `org_dimension_provider_mapping`
--









-- Dump completed on 2020-06-05 15:01:31

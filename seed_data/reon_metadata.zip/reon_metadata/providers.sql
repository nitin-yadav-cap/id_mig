-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: localhost    Database: nightly_mod
-- ------------------------------------------------------
-- Server version	8.0.25


--
-- Dumping data for table `providers`
--

REPLACE INTO `providers` (`id`, `name`, `id_str`) VALUES (1,'intouch','intouch');


-- Dump completed on 2021-10-27 12:15:34
